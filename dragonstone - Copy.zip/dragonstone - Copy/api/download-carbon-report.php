<?php
require_once '../includes/auth.php';
require_once '../includes/database.php';

if (!isLoggedIn()) {
    header('HTTP/1.0 403 Forbidden');
    exit('Access denied');
}

$conn = getDatabaseConnection();
$user_id = $_SESSION['user_id'];

// Fetch user's carbon impact data
$sql = "SELECT product_name, quantity, emitted, saved, delivery_method, created_at 
        FROM carbon_impact 
        WHERE user_id = ? 
        ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="carbon-impact-report-' . date('Y-m-d') . '.csv"');

// Create output stream
$output = fopen('php://output', 'w');

// Write CSV headers
fputcsv($output, ['Product Name', 'Quantity', 'Emissions (kg CO₂)', 'Savings (kg CO₂)', 'Delivery Method', 'Date']);

// Write data rows
while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        $row['product_name'],
        $row['quantity'],
        $row['emitted'],
        $row['saved'],
        $row['delivery_method'],
        $row['created_at']
    ]);
}

fclose($output);
$conn->close();
?>