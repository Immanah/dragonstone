<?php
echo "PHP is working! i looooove immanah";
phpinfo();
?>
